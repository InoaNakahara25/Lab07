module lab07 {
	requires java.desktop;
}