package lab07;

import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class TicTacToeGUI {
	private JButton[][] buttons = new JButton[3][3];
	private JLabel statusLabel = new JLabel ("Player X's Turn");
	private JButton resetButton = new JButton ("Reset");
	JFrame frame = new JFrame("Tic Tac Toe");
	
	
	
    public TicTacToeGUI(GameController controller) {

        frame.setSize(400, 450);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel boardPanel = new JPanel(new GridLayout(3, 3));
   

        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++) {
                buttons[i][j] = new JButton("");
                final int row = i, col = j;
                buttons[i][j].addActionListener(e -> controller.onCellClicked(row, col));
                boardPanel.add(buttons[i][j]);
            }

        resetButton.addActionListener(e -> controller.onResetClicked());

        frame.add(statusLabel, BorderLayout.NORTH);
        frame.add(boardPanel, BorderLayout.CENTER);
        frame.add(resetButton, BorderLayout.SOUTH);

        frame.setVisible(true);
    }
	
	
	
	
	public void updateBoard(char[][] board) {
		for (int i = 0; i < 3; i++)
			for (int j = 0; j < 3; j++) {
				buttons[i][j].setText(board[i][j] == ' ' ? "" : String.valueOf(board[i][j]));
			}
	}
	
	
	
	
	public void showWinner(String playerName) {
		statusLabel.setText("Winner: " + playerName);
	}
	
	
	
	
	public void showDraw() {
		statusLabel.setText("Draw");
	}
	
	
	
	
	public void clearBoard() {
		for(JButton[] row:buttons)
			for(JButton button : row) {
				button.setText("");
			}
	}
	
	
	
	
	public void showMessage(String message) {
		statusLabel.setText(message);
	}
	
	
	
	


}
