package lab07;

public class GameController {
    private GameLogic logic;
    private TicTacToeGUI gui;
    
    
    public GameController() {
        Player p1 = new HumanPlayer("Player X", 'X');
        Player p2 = new HumanPlayer("Player O", 'O');
        logic = new GameLogic(p1, p2);
        logic.startGame();
        gui = new TicTacToeGUI(this);
        gui.updateBoard(logic.getBoard());
        gui.showMessage(logic.getCurrentPlayer().getName() + "'s turn");
    }
    private boolean gameOver = false;


    public void onCellClicked(int row, int col) {
        if (gameOver) {
            gui.showMessage("Game over. Please press Reset to play again.");
            return;
        }

        if (logic.makeMove(row, col)) {
            gui.updateBoard(logic.getBoard());

            if (logic.checkWin()) {
                gui.showWinner(logic.getCurrentPlayer().getName());
                gameOver = true; 
            } else if (logic.isDraw()) {
                gui.showDraw();
                gameOver = true; 
            } else {
                logic.switchPlayer();
                gui.showMessage(logic.getCurrentPlayer().getName() + "'s turn");
            }
        } else {
            gui.showMessage("Cell is already filled. Try again.");
        }
    }

    public void onResetClicked() {
        logic.resetGame();
        gui.clearBoard();
        gui.updateBoard(logic.getBoard());
        gui.showMessage(logic.getCurrentPlayer().getName() + "'s turn");
        gameOver = false;
    }


    public static void main(String[] args) {
        new GameController();
    }
}
