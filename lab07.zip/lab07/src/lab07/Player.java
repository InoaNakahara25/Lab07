package lab07;

public interface Player {
int[] makeMove(char[][] board);
char getSymbol();
String getName();
}